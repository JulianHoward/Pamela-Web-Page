import { Box, Button, Stack, Typography, Card, CardMedia, CardContent } from '@mui/material';
import PropTypes from 'prop-types';
import { memo, useMemo } from 'react';

function NoticiasList({ noticias = [], onEdit, onDelete }) {
  // Mapeamos las noticias para normalizar los campos y usar imagen virtual
  const list = useMemo(() => {
    if (!Array.isArray(noticias)) return [];
    return noticias.map((n, idx) => ({
      id: n.id ?? n._id ?? n.uuid ?? `row-${idx}`,
      titulo: n.titulo ?? n.title ?? 'Sin título',
      contenido: n.contenido ?? n.descripcion ?? '',
      fecha: n.fecha ?? n.createdAt ?? n.updatedAt ?? null,
      // Usamos campo virtual 'imagen' si existe, sino 'imagen_url'
      imagen: n.imagen || n.imagen_url || null,
    }));
  }, [noticias]);

  const handleDeleteClick = async (id) => {
    if (onDelete) await onDelete(id);
  };

  console.log("Noticias procesadas:", list);

  if (!list.length) {
    return (
      <Box sx={{ py: 2 }}>
        <Typography variant="body1">No hay noticias.</Typography>
      </Box>
    );
  }

  return (
    <Stack spacing={4}>
      {list.map((n) => (
        <Card key={n.id} sx={{ boxShadow: 3 }}>
          {n.imagen && (
            <CardMedia
              component="img"
              height="250"
              image={n.imagen}
              alt={n.titulo}
              sx={{ objectFit: 'cover' }}
            />
          )}

          <CardContent>
            <Typography variant="h5" component="h2" gutterBottom sx={{ fontWeight: 700 }}>
              {n.titulo}
            </Typography>

            {n.fecha && (
              <Typography variant="caption" color="text.secondary" gutterBottom>
                {new Date(n.fecha).toLocaleDateString()}
              </Typography>
            )}

            <Typography variant="body1" sx={{ whiteSpace: 'pre-line', mt: 1.5 }}>
              {n.contenido}
            </Typography>

            {(onEdit || onDelete) && (
              <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
                {onEdit && (
                  <Button size="small" variant="outlined" onClick={() => onEdit(n.id)}>
                    Editar
                  </Button>
                )}
                {onDelete && (
                  <Button
                    size="small"
                    color="error"
                    variant="contained"
                    onClick={() => handleDeleteClick(n.id)}
                  >
                    Eliminar
                  </Button>
                )}
              </Stack>
            )}
          </CardContent>
        </Card>
      ))}
    </Stack>
  );
}

NoticiasList.propTypes = {
  noticias: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      _id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      uuid: PropTypes.string,
      titulo: PropTypes.string,
      title: PropTypes.string,
      contenido: PropTypes.string,
      descripcion: PropTypes.string,
      fecha: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number,
        PropTypes.instanceOf(Date),
      ]),
      createdAt: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      updatedAt: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      imagen_url: PropTypes.string,
      imagen: PropTypes.string, // Campo virtual
      imagenUrl: PropTypes.string,
    })
  ),
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
};

NoticiasList.defaultProps = {
  noticias: [],
  onEdit: undefined,
  onDelete: undefined,
};

export default memo(NoticiasList);
